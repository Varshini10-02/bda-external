-- Create a Hive table to store YouTube data
CREATE TABLE youtube_data (
    video_id STRING,
    title STRING,
    channel_id STRING,
    channel_title STRING,
    category_id INT,
    views BIGINT,
    likes BIGINT,
    dislikes BIGINT,
    comment_count BIGINT,
    published_at TIMESTAMP,
    tags ARRAY<STRING>
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
COLLECTION ITEMS TERMINATED BY '|'
LINES TERMINATED BY '\n'
STORED AS TEXTFILE;