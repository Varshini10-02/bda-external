-- Sample HiveQL queries to interact with the YouTube data table

-- Query to get the top 10 most viewed videos
SELECT video_id, title, views
FROM youtube_data
ORDER BY views DESC
LIMIT 10;

-- Query to get the total number of videos per category
SELECT category_id, COUNT(*) AS video_count
FROM youtube_data
GROUP BY category_id
ORDER BY video_count DESC;

-- Query to get the average number of likes per video
SELECT AVG(likes) AS avg_likes
FROM youtube_data;

-- Query to get the top 5 channels with the most videos
SELECT channel_id, channel_title, COUNT(*) AS video_count
FROM youtube_data
GROUP BY channel_id, channel_title
ORDER BY video_count DESC
LIMIT 5;